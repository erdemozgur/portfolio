//
//  QuestionBank.swift
//  Quizzler
//
//  Created by erdem ozgur on 25.04.2018.
//  Copyright © 2018 London App Brewery. All rights reserved.
//

import Foundation
class QuestionBank{
    
    var list = [Question]();
    
    init() {
        list.append(Question(text: "Her hapşırıkta, beyin hücrelerinin bir kısmı ölür.", answer: true));
        list.append(Question(text: " İpek böcekleri, 95 günde kendi ağırlıklarının 26.000 katı kadar beslenirler.", answer: false));
        list.append(Question(text: "Çin Seddi aydan görünebilir.", answer: false));
        list.append(Question(text: "7. 111.111.111 x 111.111.111 = 12.345.678.987.654.321", answer: true));
        list.append(Question(text: "Gökkuşağında yedi renk vardır", answer: false));
        list.append(Question(text: "Soğan doğrarken sakız çiğnerseniz ağlamazsınız.", answer: true));
        list.append(Question(text: "Kelebeklerin ömrü bir gündür", answer: false));
        list.append(Question(text: "Bukalemunlar tehlike hissettikleri anda kamuflaj amacıyla renk değiştirirler", answer: false));
        list.append(Question(text: "Çok şeker yiyen şeker hastası olur", answer: false))
        list.append(Question(text: "Brezilya'nın başkenti Rio de Janerio'dur", answer: false))
        list.append(Question(text: "Ispanak insanı güçlendirir", answer: false))
        list.append(Question(text: "Alexander Graham Bell telefonu icat etti", answer: false))
        list.append(Question(text: "İlk ampul Thomas Edison tarafından icat edilmiştir", answer: false))
        




        
        
    }
    
    
};
