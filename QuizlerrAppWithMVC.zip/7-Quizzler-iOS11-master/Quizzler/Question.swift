//
//  Question.swift
//  Quizzler
//
//  Created by erdem ozgur on 25.04.2018.
//  Copyright © 2018 London App Brewery. All rights reserved.
//

import Foundation

class Question {
    let questionText : String;
    let questionAnswer : Bool;
    
    init(text : String, answer : Bool) {
        questionText = text;
        questionAnswer = answer;
    }
    
    
    
};
