import UIKit
import SpriteKit

class GameViewController: UIViewController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    if let view = self.view as! SKView? {
      if let scene = GameScene.loadGame()
        ?? SKScene(fileNamed: "Level1") as? GameScene {
        scene.scaleMode = .resizeFill
        
        // Present the scene
        view.presentScene(scene)
      }
      
      view.ignoresSiblingOrder = true
      
      view.showsFPS = true
      view.showsNodeCount = true
      view.showsPhysics = true
    }
  }
  
  override var prefersStatusBarHidden: Bool {
    return true
  }
}
