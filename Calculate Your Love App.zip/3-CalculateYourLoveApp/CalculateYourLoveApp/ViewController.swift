//
//  ViewController.swift
//  CalculateYourLoveApp
//
//  Created by erdem ozgur on 06/04/2018.
//  Copyright © 2018 erdem ozgur. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var isimKullanici: UITextField!
    @IBOutlet weak var isimOnun: UITextField!
    @IBOutlet weak var sliderOutlet: UISlider!
    @IBOutlet weak var sliderLabelOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func buttonAskOlcer(_ sender: Any) {
        let alert = UIAlertController(title: "Sonucunuz:", message: "AAA"  , preferredStyle: .alert)
        let action = UIAlertAction(title: "Avesome", style: .default, handler: nil)
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
        
        alert.message =  AskDegeri(yourName: isimKullanici.text!, theirName: isimOnun.text!)
        

}
    @IBAction func sliderAction(_ sender: UISlider) {
        
    }
    func AskDegeri(yourName : String , theirName : String) -> String{
        
        let randomNumber = Int(arc4random_uniform(101))
        let askSkoru = randomNumber
        sliderOutlet.value = Float(askSkoru)
        sliderLabelOutlet.text = String(askSkoru)
        
        if askSkoru > 80 {
            return "Merhaba \(isimKullanici.text!) ve \(isimOnun.text!) Ask skorun \(randomNumber). Birbirinize deliler gibi aşıksınız"
        }
        else if askSkoru > 40 && askSkoru <= 80 {
            return "Merhaba \(isimKullanici.text!) ve \(isimOnun.text!) Aşk skorun \(randomNumber). Siz kolayla mentos gibisiniz."
            }
            else {
                return "Merhaba \(isimKullanici.text!) ve \(isimOnun.text!) Aşk skorun \(randomNumber). Bu aşk imkansiz, sonsuza kadar yalniz kalacaksin!"
            }
      
        
        
        
    }

}
